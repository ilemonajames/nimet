@extends("home.app")

@section("content")

<!-- Banner Section Start -->
<section class="banner-style-4 banner-padding">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-md-12 col-xl-6 col-lg-6">
                <div class="banner-content ">
                    <span class="subheading">Over 3000 Course Available</span>
                    <h1>Upgrade your learning Skills to earn you a life time experience</h1>
                    <p class="mb-40"> Advance your career in business analytics, statistics, economic management and more.</p>

                    <div class="btn-container">
                        <a href="#" class="btn btn-main rounded">Find Courses</a>
                        <a href="#" class="btn btn-white rounded ms-2">Get started </a>
                    </div>
                </div>
            </div>

            <div class="col-md-12 col-xl-6 col-lg-6">
                <div class="banner-img-round mt-5 mt-lg-0 ps-5">
                    <img src="assets/images/banner/banner_img.png" alt="" class="img-fluid">
                </div>
            </div>
        </div> <!-- / .row -->
    </div> <!-- / .container -->
</section>
<!-- Banner Section End -->

<!-- Counter Section start -->
<section class="counter-section4">
    <div class="container">
        <div class="row justify-content-center" >
            <div class="col-xl-12 counter-inner">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="counter-item mb-5 mb-lg-0">
                            <div class="count">
                                <span class="counter h2">2000</span><span>+</span>
                            </div>
                            <p>Students</p>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="counter-item mb-5 mb-lg-0">
                            <div class="count">
                                <span class="counter h2">1200</span>
                            </div>
                            <p>Online Courses</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="counter-item mb-5 mb-lg-0">
                            <div class="count">
                                <span class="counter h2">2256</span>
                            </div>
                            <p>Finished Seasons</p>     
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="counter-item">
                            <div class="count">
                                <span class="counter h2">100</span><span>%</span>
                            </div>
                            <p>Satisfaction</p>     
                        </div>
                    </div>
                </div>
            </div>
       </div>
    </div>
</section>
<!-- COunter Section End -->




<!--  Course style 1 -->

<section class="course-wrapper section-padding ">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-8">
                <div class="section-heading mb-70 text-center">
                    <h2 class="font-lg">Popular Courses</h2>
                    <p>Discover Your Perfect Program In Our Courses.</p>
                </div>
            </div>
        </div>

        <div class="row justify-content-lg-center">
            <div class="col-xl-4 col-lg-4 col-md-6">
                <div class="course-grid bg-shadow tooltip-style">
                    <div class="course-header">
                        <div class="course-thumb">
                            <img src="usermedia/WhatsApp_Image_2022-08-16_at_17.50.48.jpeg" alt="" class="img-fluid">
                            <div style="display: none" class="course-price">300</div>
                        </div>
                    </div>
    
                    <div class="course-content">
                        <div class="rating mb-10">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>

                            <span>3.9 (30 reviews)</span>
                        </div>

                        <h3 class="course-title mb-20"> <a href="#">Introduction to Remote Sensing & GIS </a> </h3>

                        <div class="course-footer mt-20 d-flex align-items-center justify-content-between ">
                            <span class="duration"><i class="far fa-clock me-2"></i>6.5 hr</span>
                            <span class="students"><i class="far fa-user-alt me-2"></i>51 Students</span>
                            <span class="lessons"><i class="far fa-play-circle me-2"></i>26 Lessons</span>
                        </div>
                    </div>
    
                    <div class="course-hover-content">
                        <div style="display: none" class="price">300</div>
                        <h3 class="course-title mb-20 mt-30"> <a href="#">Introduction to Remote Sensing & GIS </a> </h3>
                        <div class="course-meta d-flex align-items-center mb-20">
                            <div class="author me-4">
                                <img src="assets/images/course/course-2.jpg" alt="" class="img-fluid">
                                <a href="#">Kemi</a>
                            </div>
                            <span class="lesson"> <i class="far fa-file-alt"></i> 20 lessons</span>
                        </div>
                        <p class="mb-20">Remote sensing is a surveying and data collection technique, used to survey and collect data regarding an object</p>
                        <a href="#" class="btn btn-grey btn-sm rounded">Apply Now <i class="fal fa-angle-right"></i></a>
                    </div>
                </div>
             </div>
            <!-- COURSE END -->

            <div class="col-xl-4 col-lg-4 col-md-6">
                <div class="course-grid bg-shadow tooltip-style">
                    <div class="course-header">
                        <div class="course-thumb">
                            <img src="usermedia/WhatsApp_Image_2022-08-16_at_17.51.37.jpeg" alt="" class="img-fluid">
                            <div style="display: none" class="course-price">300</div>
                        </div>
                    </div>
    
                    <div class="course-content">
                        <div class="rating mb-10">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>

                            <span>3.9 (30 reviews)</span>
                        </div>

                        <h3 class="course-title mb-20"> <a href="#">Climatological Statistics</a> </h3>
                        <div class="course-footer mt-20 d-flex align-items-center justify-content-between ">
                            <span class="duration"><i class="far fa-clock me-2"></i>6.5 hr</span>
                            <span class="students"><i class="far fa-user-alt me-2"></i>51 Students</span>
                            <span class="lessons"><i class="far fa-play-circle me-2"></i>26 Lessons</span>
                        </div>
                    </div>
    
                    <div class="course-hover-content">
                        <div style="display: none" class="price">300</div>
                        <h3 class="course-title mb-20 mt-30"> <a href="#">Climatological Statistics </a> </h3>
                        <div class="course-meta d-flex align-items-center mb-20">
                            <div class="author me-4">
                                <img src="assets/images/course/course-2.jpg" alt="" class="img-fluid">
                                <a href="#">Sarah</a>
                            </div>
                            <span class="lesson"> <i class="far fa-file-alt"></i> 20 lessons</span>
                        </div>
                        <p class="mb-20">Climatological statistics may be derived from corresponding portions of the annual cycle in a set of years</p>
                        <a href="#" class="btn btn-grey btn-sm rounded">Apply Now <i class="fal fa-angle-right"></i></a>
                    </div>
                </div>
             </div>
            <!-- COURSE END -->
            
            <div class="col-xl-4 col-lg-4 col-md-6">
                <div class="course-grid bg-shadow tooltip-style">
                    <div class="course-header">
                        <div class="course-thumb">
                            <img src="usermedia/WhatsApp_Image_2022-08-16_at_17.51.14.jpeg" alt="" class="img-fluid">
                            <div style="display: none" class="course-price">300</div>
                        </div>
                    </div>
    
                    <div class="course-content">
                        <div class="rating mb-10">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>

                            <span>3.9 (30 reviews)</span>
                        </div>

                        <h3 class="course-title mb-20"> <a href="#">Introduction to Climatology</a> </h3>

                    
                        <div class="course-footer mt-20 d-flex align-items-center justify-content-between ">
                            <span class="duration"><i class="far fa-clock me-2"></i>6.5 hr</span>
                            <span class="students"><i class="far fa-user-alt me-2"></i>51 Students</span>
                            <span class="lessons"><i class="far fa-play-circle me-2"></i>26 Lessons</span>
                        </div>
                    </div>
    
                    <div class="course-hover-content">
                        <div style="display: none" class="price">300</div>
                        <h3 class="course-title mb-20 mt-30"> <a href="#">Introduction to Climatology </a> </h3>
                        <div class="course-meta d-flex align-items-center mb-20">
                            <div class="author me-4">
                                <img src="assets/images/course/course-2.jpg" alt="" class="img-fluid">
                                <a href="#">Chidiogo</a>
                            </div>
                            <span class="lesson"> <i class="far fa-file-alt"></i> 20 lessons</span>
                        </div>
                        <p class="mb-20">Climatology is the study of the atmosphere and weather patterns over time. This field of science focuses on recording and analyzing weather patterns throughout the world and understanding the atmospheric conditions that cause them</p>
                        <a href="#" class="btn btn-grey btn-sm rounded">Apply Now <i class="fal fa-angle-right"></i></a>
                    </div>
                </div>
             </div>
            <!-- COURSE END -->
        </div>
    </div>
</section>

<!--  Course style 1 End -->




<!--  Course category -->
<section class="course-category-3 section-padding">
    <div class="container">
        <div class="row mb-70 justify-content-center">
            <div class="col-xl-8">
                <div class="section-heading text-center">
                    <h2 class="font-lg">Categories you want to learn</h2>
                    <p>Select your favourite categories from list</p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xl col-lg-4 col-sm-6">
                <div class="single-course-category style-3 bg-1">
                    <div class="course-cat-icon">
                        <img src="assets/images/icon/icon1.png" alt="" class="img-fluid">
                    </div>
                    <div class="course-cat-content">
                        <h4 class="course-cat-title">
                            <a href="#">Data Science & Analytics</a>
                        </h4>
                    </div>
                </div>
            </div>

            <div class="col-xl col-lg-4 col-sm-6">
                <div class="single-course-category style-3 bg-2">
                    <div class="course-cat-icon">
                        <img src="assets/images/icon/icon2.png" alt="" class="img-fluid">
                    </div>
                    <div class="course-cat-content">
                        <h4 class="course-cat-title">
                            <a href="#">Artificial Intellegence</a>
                        </h4>
                    </div>
                </div>
            </div>

            <div class="col-xl col-lg-4 col-sm-6">
                <div class="single-course-category style-3 bg-3">
                    <div class="course-cat-icon">
                        <img src="assets/images/icon/icon3.png" alt="" class="img-fluid">
                    </div>
                    <div class="course-cat-content">
                        <h4 class="course-cat-title">
                            <a href="#">Algebra Math calculation</a>
                        </h4>
                    </div>
                </div>
            </div>

            <div class="col-xl col-lg-4 col-sm-6">
                <div class="single-course-category style-3 bg-4">
                    <div class="course-cat-icon">
                        <img src="assets/images/icon/icon4.png" alt="" class="img-fluid">
                    </div>
                    <div class="course-cat-content">
                        <h4 class="course-cat-title">
                            <a href="#">Web Development</a>
                        </h4>
                    </div>
                </div>
            </div>

            <div class="col-xl col-lg-4 col-sm-6">
                <div class="single-course-category style-3 bg-5">
                    <div class="course-cat-icon">
                        <img src="assets/images/icon/icon6.png" alt="" class="img-fluid">
                    </div>
                    <div class="course-cat-content">
                        <h4 class="course-cat-title">
                            <a href="#">Digital Marketing & SEO</a>
                        </h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--  Course category End -->
<!-- Work Process Section Start -->
<section class="work-process section-padding">
    <div class="container">
        <div class="row mb-40">
            <div class="col-xl-8">
                <div class="section-heading ">
                    <h2 class="font-lg">Start your journey With us</h2>
                    <p>We are the best learning portal</p>
                </div>
            </div>
        </div>

        <div class="row align-items-center">
            <div class="col-xl-7 pe-xl-5 col-lg-12">
                <div class="row">
                    <div class="col-xl-6 col-lg-6 col-md-6">
                        <div class="step-item ">
                            <div class="step-number bg-1">01</div>
                            <div class="step-text">
                                <h5>Signup with all info</h5>
                                <p>Become our student</p>
                            </div>
                        </div>
                    </div>
        
                    <div class="col-xl-6 col-lg-6 col-md-6">
                        <div class="step-item">
                            <div class="step-number bg-2">02</div>
                            <div class="step-text">
                                <h5>Pay for courses</h5>
                                <p>Our courses are affordable</p>
                            </div>
                        </div>
                    </div>
        
                    <div class="col-xl-6 col-lg-6 col-md-6 ">
                        <div class="step-item">
                            <div class="step-number bg-3">03</div>
                            <div class="step-text">
                                <h5>Learn from online </h5>
                                <p>start learning from your home with ease</p>
                            </div>
                        </div>
                    </div>
        
                    <div class="col-xl-6 col-lg-6 col-md-6">
                        <div class="step-item">
                            <div class="step-number bg-1">04</div>
                            <div class="step-text">
                                <h5>Get certificate</h5>
                                <p>certificate will be given to every students.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-5">
                <div class="video-section mt-3 mt-xl-0">
                    <div class="video-content">
                        <img src="assets/images/bg/office01.jpg" alt="" class="img-fluid">
                        <a href="#" class="video-icon video-popup"><i class="fa fa-play"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Work Process Section End -->
<!--  Course style 1 -->

<section class="course-wrapper section-padding  bg-gray">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-8">
                <div class="section-heading mb-70 text-center">
                    <h2 class="font-lg">Popular Courses</h2>
                    <p>Discover Your Perfect Program In Our Courses.</p>
                </div>
            </div>
        </div>

        <div class="row justify-content-lg-center">
            <div class="col-xl-3 col-lg-6 col-md-6">
                <div class="course-grid tooltip-style bg-white hover-shadow">
                    <div class="course-header">
                        <div class="course-thumb">
                            <img src="assets/images/course/img_01.jpg" alt="" class="img-fluid">
                            <div style="display: none" class="course-price">300</div>
                        </div>
                    </div>
    
                    <div class="course-content">
                        <div class="rating mb-10">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>

                            <span>3.9 (30 reviews)</span>
                        </div>
                        <h3 class="course-title mb-20"> <a href="#">SQL-Data Analysis: Crash Course</a> </h3>
                        <div class="course-footer mt-20 d-flex align-items-center justify-content-between ">
                            <span class="duration"><i class="far fa-clock me-2"></i>6.5 hr</span>
                            <span class="lessons"><i class="far fa-play-circle me-2"></i>26 Lessons</span>
                        </div>
                    </div>
                </div>
             </div>
            <!-- COURSE END -->

            <div class="col-xl-3 col-lg-6 col-md-6">
                <div class="course-grid tooltip-style bg-white hover-shadow">
                    <div class="course-header">
                        <div class="course-thumb">
                            <img src="assets/images/course/img_05.jpg" alt="" class="img-fluid">
                            <div style="display: none" class="course-price">300</div>
                        </div>
                    </div>
    
                    <div class="course-content">
                        <div class="rating mb-10">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>

                            <span>3.9 (30 reviews)</span>
                        </div>
                        <h3 class="course-title mb-20"> <a href="#">Learn How to Start an Amazon FBA Store</a> </h3>
                        <div class="course-footer mt-20 d-flex align-items-center justify-content-between ">
                            <span class="duration"><i class="far fa-clock me-2"></i>6.5 hr</span>
                            <span class="lessons"><i class="far fa-play-circle me-2"></i>26 Lessons</span>
                        </div>
                    </div>
                </div>
             </div>
            <!-- COURSE END -->

            <div class="col-xl-3 col-lg-6 col-md-6">
                <div class="course-grid tooltip-style bg-white hover-shadow">
                    <div class="course-header">
                        <div class="course-thumb">
                            <img src="assets/images/course/img_02.jpg" alt="" class="img-fluid">
                            <div style="display: none" class="course-price">300</div>
                        </div>
                    </div>
    
                    <div class="course-content">
                        <div class="rating mb-10">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>

                            <span>3.9 (30 reviews)</span>
                        </div>
                    
                        <h3 class="course-title mb-20"> <a href="#">Emotional Intelligence at Work: Learn Emotions</a> </h3>
                       
                        <div class="course-footer mt-20 d-flex align-items-center justify-content-between ">
                            <span class="duration"><i class="far fa-clock me-2"></i>6.5 hr</span>
                            <span class="lessons"><i class="far fa-play-circle me-2"></i>26 Lessons</span>
                        </div>
                    </div>
                </div>
             </div>
            <!-- COURSE END -->
            
            <div class="col-xl-3 col-lg-6 col-md-6">
                <div class="course-grid tooltip-style bg-white hover-shadow">
                    <div class="course-header">
                        <div class="course-thumb">
                            <img src="assets/images/course/img_03.jpg" alt="" class="img-fluid">
                            <div style="display: none" class="course-price">300</div>
                        </div>
                    </div>
    
                    <div class="course-content">
                        <div class="rating mb-10">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>

                            <span>3.9 (30 reviews)</span>
                        </div>
                    
                        <h3 class="course-title mb-20"> <a href="#">Competitive Strategy law & Organization </a> </h3>
                      
                        <div class="course-footer mt-20 d-flex align-items-center justify-content-between ">
                            <span class="duration"><i class="far fa-clock me-2"></i>6.5 hr</span>
                            <span class="lessons"><i class="far fa-play-circle me-2"></i>26 Lessons</span>
                        </div>
                    </div>
                </div>
             </div>
            <!-- COURSE END -->
        </div>
    </div>
</section>

<!--  Course style 1 End -->



<!-- Feature section start -->
<section class="features-3 section-padding-top ">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-8">
                <div class="section-heading mb-50 text-center">
                    <h2 class="font-lg">Transform Your Life </h2>
                    <p>Discover Your Perfect Program In Our Courses.</p>
                </div>
            </div>
        </div>

        <div class="row ">
            <div class="col-lg-3 col-md-6 col-xl-3 col-sm-6">
                <div class="feature-item feature-style-top hover-shadow rounded border-0">
                    <div class="feature-icon">
                        <i class="flaticon-teacher"></i>
                    </div>
                    <div class="feature-text">
                        <h4>Expert Teacher</h4>
                        <p>Develop skills for career of various majors including computer</p>
                    </div>
                </div>
            </div>
             <div class="col-lg-3 col-md-6 col-xl-3 col-sm-6">
                <div class="feature-item feature-style-top hover-shadow rounded border-0">
                    <div class="feature-icon">
                        <i class="flaticon-layer"></i>
                    </div>
                    <div class="feature-text">
                        <h4>Self Development</h4>
                        <p>Develop skills for career of various majors including computer.</p>
                    </div>
                </div>
            </div>
             <div class="col-lg-3 col-md-6 col-xl-3 col-sm-6">
                <div class="feature-item feature-style-top hover-shadow rounded border-0">
                    <div class="feature-icon">
                        <i class="flaticon-video-camera"></i>
                    </div>
                    <div class="feature-text">
                        <h4>Remote Learning</h4>
                        <p>Develop skills for career of various majors including language</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-xl-3 col-sm-6">
                <div class="feature-item feature-style-top hover-shadow rounded border-0">
                    <div class="feature-icon">
                        <i class="flaticon-lifesaver"></i>
                    </div>
                    <div class="feature-text">
                        <h4>Life Time Support</h4>
                        <p>Develop skills for career of various majors including language  </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Feature section End -->
<!-- Team section start -->
<section class="team section-padding">
    <div class="container">
        <div class="row  mb-100">
            <div class="col-lg-8 col-xl-8">
                <div class="section-heading text-center text-lg-start">
                    <h2 class="font-lg">Top Rated Instructors</h2>
                    <p>Discover Your Perfect Program In Our Courses.</p>
                </div>
            </div>

             <div class="col-xl-4 col-lg-4">
                <div class="text-center text-lg-end">
                    <a href="#" class="btn btn-main-outline rounded">All Instructors <i class="fa fa-angle-right"></i></a>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xl-3 col-lg-4 col-sm-6">
                <div class="team-item team-item-4 mb-70 mb-xl-0">
                    <div class="team-img">
                        <img src="assets/images/team/no-image.png" alt="" class="img-fluid">

                        <ul class="team-socials list-inline">
                            <li class="list-inline-item"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li class="list-inline-item"><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li class="list-inline-item"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        </ul>
                    </div>
                    <div class="team-content">
                        <div class="team-info">
                            <h4>Samuel Adewale</h4>
                            <p>SEO Expert</p>
                        </div>

                        <div class="course-meta">
                            <span class="duration"><i class="far fa-user-alt"></i>20 Students</span>
                            <span class="lessons"><i class="far fa-play-circle me-2"></i>2 Course</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-sm-6">
                <div class="team-item team-item-4 mb-70 mb-xl-0">
                    <div class="team-img">
                        <img src="assets/images/team/no-image.png" alt="" class="img-fluid">
                        <ul class="team-socials list-inline">
                            <li class="list-inline-item"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li class="list-inline-item"><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li class="list-inline-item"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        </ul>
                    </div>
                    <div class="team-content">
                        <div class="team-info">
                            <h4>James IIemona</h4>
                            <p>CEO, Developer</p>
                        </div>
                        <div class="course-meta">
                            <span class="duration"><i class="far fa-user-alt"></i>20 Students</span>
                            <span class="lessons"><i class="far fa-play-circle me-2"></i>2 Course</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-6">
                <div class="team-item team-item-4 mb-70 mb-xl-0">
                    <div class="team-img">
                        <img src="assets/images/team/no-image.png" alt="" class="img-fluid">

                        <ul class="team-socials list-inline">
                            <li class="list-inline-item"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li class="list-inline-item"><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li class="list-inline-item"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        </ul>
                    </div>
                    <div class="team-content">
                        <div class="team-info">
                            <h4>Omeiza Alabi</h4>
                            <p>Web eveloper</p>
                        </div>
                        <div class="course-meta">
                            <span class="duration"><i class="far fa-user-alt"></i>20 Students</span>
                            <span class="lessons"><i class="far fa-play-circle me-2"></i>2 Course</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-4 col-sm-6">
                <div class="team-item team-item-4">
                    <div class="team-img">
                        <img src="assets/images/team/no-image.png" alt="" class="img-fluid">

                        <ul class="team-socials list-inline">
                            <li class="list-inline-item"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li class="list-inline-item"><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li class="list-inline-item"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        </ul>
                    </div>
                    <div class="team-content">
                        <div class="team-info">
                            <h4>Victoria Ugwu</h4>
                            <p>UI/UX designer</p>
                        </div>

                        <div class="course-meta">
                            <span class="duration"><i class="far fa-user-alt"></i>20 Students</span>
                            <span class="lessons"><i class="far fa-play-circle me-2"></i>2 Course</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Team section End -->

<!-- Testimonial section start -->
<section class="testimonial-4 section-padding bg-gray">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6">
                <div class="section-heading text-center mb-50">
                    <h2 class="font-lg">Our Students Says</h2>
                    <p>Discover Your Perfect Program In Our Courses.</p>
                </div>
            </div>
        </div>
        <div class="row align-items-center">
            <div class="col-lg-12 col-xl-12">
                <div class="testimonials-slides owl-carousel owl-theme">
                    <div class="testimonial-item">
                       <div class="testimonial-inner">
                           <div class="quote-icon"><i class="flaticon-left-quote"></i></div>
                           
                            <div class="testimonial-text mb-30">
                               Piratech is the right choice for software development
                            </div>

                            <div class="client-info d-flex align-items-center">
                                <div class="client-img">
                                    <img src="assets/images/team/no-image.png" alt="" class="img-fluid">
                                </div>
                                <div class="testimonial-author">
                                    <h4>David Abraham</h4>
                                    <span class="meta">Marketing Specialist</span>
                                </div>
                            </div>
                       </div>
                    </div>

                    <div class="testimonial-item">
                        <div class="testimonial-inner">
                            <div class="quote-icon"><i class="flaticon-left-quote"></i></div>
                           
                            <div class="testimonial-text  mb-30">
                                good job
                            </div>

                            <div class="client-info d-flex align-items-center">
                                <div class="client-img">
                                    <img src="assets/images/team/no-image.png" alt="" class="img-fluid">
                                </div>
                                <div class="testimonial-author">
                                    <h4>Jackie Appiah</h4>
                                    <span class="meta">Marketing Manager</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="testimonial-item">
                        <div class="testimonial-inner">
                            <div class="quote-icon"><i class="flaticon-left-quote"></i></div>
                          
                            <div class="testimonial-text  mb-30">
                                we are impressed
                            </div>

                            <div class="client-info d-flex align-items-center">
                                <div class="client-img">
                                    <img src="assets/images/team/no-image.png" alt="" class="img-fluid">
                                </div>
                                <div class="testimonial-author">
                                    <h4>Nikolas Nelson</h4>
                                    <span class="meta">Sales Manager</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="testimonial-item">
                        <div class="testimonial-inner">
                            <div class="quote-icon"><i class="flaticon-left-quote"></i></div>
                            
                            <div class="testimonial-text mb-30">
                                They don't dissapoint
                            </div>

                            <div class="client-info d-flex align-items-center">
                                <div class="client-img">
                                    <img src="assets/images/team/no-image.png" alt="" class="img-fluid">
                                </div>
                                <div class="testimonial-author">
                                    <h4>Jocob Anabel</h4>
                                    <span class="meta">Marketing Manager</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="testimonial-item">
                        <div class="testimonial-inner">
                            <div class="quote-icon"><i class="flaticon-left-quote"></i></div>
                            
                            <div class="testimonial-text mb-30">
                                nice work
                            </div>

                            <div class="client-info d-flex align-items-center">
                                <div class="client-img">
                                    <img src="assets/images/team/no-image.png" alt="" class="img-fluid">
                                </div>
                                <div class="testimonial-author">
                                    <h4>Elizabeth Eze</h4>
                                    <span class="meta">Sales Manager</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Testimonial section End -->
<!-- CTA Sidebar start -->
<section class="cta-5 mb--120 bg-gray">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-12">
                <div class="cta-inner4">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-xl-4 col-lg-5">
                           <div class="cta-img mb-4 mb-lg-0">
                               <img src="assets/images/about/img_9.png" alt="" class="img-fluid">
                           </div>
                        </div>
                        <div class="col-xl-6 col-lg-6">
                            <div class="cta-content ps-lg-4">
                                <span class="subheading mb-10">Not sure where to start?</span>
                                <h2 class="mb-20"> Want to know Special Offers & Updates of new courses?</h2>
                                <a href="#" class="btn btn-main rounded"> Join NOw</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection