@include("home.header")
@yield("content")
@include("home.footer")